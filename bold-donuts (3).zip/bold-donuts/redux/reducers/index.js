import { combineReducers } from "redux";
import movie from "./movie";

export default combineReducers({ movie });

