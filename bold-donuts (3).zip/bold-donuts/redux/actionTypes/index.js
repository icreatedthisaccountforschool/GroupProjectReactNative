export const = "";
export const = "";

//the action types have to be named and written the same btw export const and the quotations
//whatever action types you want is up to you and the other group members
//default action types as defined in the week 6 slides are COUNTER_INCREASE and COUNTER_DECREASE