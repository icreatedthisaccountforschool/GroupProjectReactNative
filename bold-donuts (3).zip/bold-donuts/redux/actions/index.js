import {} from "../actionTypes";

export const = => ({
  type: ,
  payload: {
    
  }
});

export const = => ({
  type: ,
  payload: {
    
  }
});

//type is the variables defined in actionTypes, you can decide what to place inside
//make up whatever variables you'd like btw const and =, and btw = and =>
//refer to the week 6 slides and any online resource for Redux to finish this
//you may copy and paste these templates as many times as necessary for the app